---
name: Kinetic Minimalist
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#45464d'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#0051d5'
  on-secondary: '#ffffff'
  secondary-container: '#316bf3'
  on-secondary-container: '#fefcff'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#191c1e'
  on-tertiary-container: '#818486'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b4c5ff'
  on-secondary-fixed: '#00174b'
  on-secondary-fixed-variant: '#003ea8'
  tertiary-fixed: '#e0e3e5'
  tertiary-fixed-dim: '#c4c7c9'
  on-tertiary-fixed: '#191c1e'
  on-tertiary-fixed-variant: '#444749'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display:
    fontFamily: Hanken Grotesk
    fontSize: 4.5rem
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 2.5rem
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: '1.7'
  body-md:
    fontFamily: Inter
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: '1.6'
  label-code:
    fontFamily: JetBrains Mono
    fontSize: 0.875rem
    fontWeight: '500'
    lineHeight: '1.5'
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: '1.2'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  container-max: 1140px
  gutter: 32px
  section-gap: 128px
  element-gap: 24px
---

## Brand & Style
The design system is engineered for the modern full-stack engineer: precise, high-performance, and intellectually rigorous. It targets hiring managers and technical recruiters who value clarity over decoration. 

The aesthetic is **Modern Minimalism** with a technical edge. It leverages generous whitespace to create a "gallery" feel for code and projects, ensuring that the developer's work is the focal point. By combining high-contrast typography with subtle interactive depth, the UI feels both established and technologically forward. The emotional response should be one of immediate trust, professional competence, and attention to detail.

## Colors
The palette is rooted in a "Deep Slate" foundation to provide a sophisticated alternative to pure black. 

- **Primary (Deep Slate):** Used for primary text, headings, and heavy structural elements to anchor the page.
- **Secondary (Electric Blue):** A high-vibrancy accent reserved for call-to-actions, active states, and critical highlights (like "Current Role" or "Available for Hire").
- **Neutral (Slate Grey):** Used for secondary information, meta-data, and borders to maintain hierarchy without clutter.
- **Surface (Crisp White/Ghost White):** Large expanses of white space drive the "premium" feel and maximize readability.

## Typography
The typography system uses a functional pairing of a sharp, contemporary Grotesk for impact and a systematic Neo-grotesque for legibility.

- **Headlines:** Use **Hanken Grotesk** with tight letter-spacing. Large headers should feel architectural and bold.
- **Body:** **Inter** provides a neutral, highly readable experience for project descriptions and technical summaries.
- **Technical Meta:** **JetBrains Mono** is introduced for tech stacks, labels, and snippets to reinforce the "Full-Stack" developer identity through a developer-centric typeface.

## Layout & Spacing
This design system utilizes a **Fixed Grid** approach for desktop to maintain a curated, editorial look, transitioning to a fluid model for mobile devices.

- **Grid:** A 12-column grid with a maximum width of 1140px. 
- **Sectioning:** Extreme vertical spacing (128px+) is used between major resume sections (Experience, Projects, Education) to prevent the "wall of text" effect seen in traditional CVs.
- **Alignment:** Consistent left-alignment for all content to mimic a terminal or a well-structured document, enhancing scanning speed for recruiters.

## Elevation & Depth
To maintain a professional and "flat-plus" aesthetic, elevation is handled through **Tonal Layers** and **Low-contrast Outlines** rather than heavy shadows.

- **Surface Levels:** The main background is white (#FFFFFF). Secondary containers (like code blocks or project cards) use a subtle slate tint (#F8FAFC).
- **Outlines:** Use 1px borders in a very light slate (#E2E8F0) to define areas without creating visual weight.
- **Interaction:** On hover, cards or buttons should use a soft, "ambient" shadow (0 10px 25px -5px rgba(15, 23, 42, 0.1)) to indicate depth and interactivity.

## Shapes
Shapes are disciplined and "Soft" (0.25rem - 0.75rem). This avoids the playfulness of fully rounded "pill" shapes while softening the harshness of zero-radius corners. It suggests precision—like a well-organized IDE or a professional dashboard.

## Components
### Buttons
- **Primary:** Solid Deep Slate background with white text. No border. Soft corners (4px).
- **Ghost:** Transparent background with Slate border. Subtle Electric Blue text on hover.

### Project Cards
- Minimalist containers with a 1px Slate-200 border. 
- Use the `label-code` typography for the "Tech Stack" section at the bottom of the card, styled as subtle text strings rather than heavy chips.

### Chips (Skill Tags)
- Low-contrast backgrounds (Slate-100) with Slate-700 text. 
- No heavy borders; let the typography and background tint do the work.

### Lists (Work Experience)
- Use custom Electric Blue markers for bullet points to draw the eye to achievements.
- Vertical "timeline" lines should be thin (1px) and light (Slate-200).

### Input Fields
- Underline-only or subtle 4-sided borders. When focused, the border transitions to Electric Blue.